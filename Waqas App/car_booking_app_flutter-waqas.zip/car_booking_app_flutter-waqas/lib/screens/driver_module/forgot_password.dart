import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:stranded/widgets/back_button.dart';
import 'package:stranded/widgets/button_widget.dart';
import 'package:stranded/widgets/input_feild.dart';

import 'Login.dart';
import 'email_verification.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

TextEditingController _email_controller_forgot_password =
    TextEditingController();

class _ForgotPasswordState extends State<ForgotPassword> {
  // void dispose() {
  //   _email_controller_forgot_password.dispose();
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          reverse: true,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              child: Column(
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height * 0.54,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            backbutton(context, () {
                              Navigator.of(context).pushAndRemoveUntil(
                                MaterialPageRoute(
                                  builder: (BuildContext context) => Login(),
                                ),
                                (Route<dynamic> route) => false,
                              );
                            },
                                Theme.of(context).primaryColor,
                                Icons.navigate_before_outlined,
                                Theme.of(context).scaffoldBackgroundColor),
                            Padding(
                              padding: const EdgeInsets.only(left: 75),
                              child: Text(
                                "Forgot Password",
                                style: Theme.of(context).textTheme.titleLarge,
                              ),
                            )
                          ],
                        ),
                        SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                                "assets/driver_module/forgot_pass_pic.png"),
                          ],
                        ),
                        SizedBox(height: 30),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("Please Enter Your Email Address to",
                                style:
                                    Theme.of(context).textTheme.headlineMedium),
                          ],
                        ),
                        SizedBox(height: 2),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("Receive a Verification Code.",
                                style:
                                    Theme.of(context).textTheme.headlineMedium),
                          ],
                        )
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Email Address",
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                          SizedBox(height: 5),
                          InputFeild("Email Address", null,
                              _email_controller_forgot_password),
                          SizedBox(height: 5),
                          Center(
                              child: TextButton(
                            onPressed: () {},
                            child: Text(
                              "Try another way",
                              style: TextStyle(
                                  color: Colors.red,
                                  fontWeight: FontWeight.w900),
                            ),
                          )),
                          SizedBox(height: 50),
                          Center(
                              child: ButtonWidget("Send", context, () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const EmailVerification()),
                            );
                          })),
                        ]),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
