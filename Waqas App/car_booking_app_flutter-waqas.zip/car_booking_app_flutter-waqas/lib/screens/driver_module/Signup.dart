
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:stranded/screens/driver_module/Login.dart';
import 'package:stranded/widgets/button_widget.dart';
import 'package:stranded/widgets/input_feild.dart';
import '../../widgets/text_navigation.dart';
import 'number_verification.dart';

class Signup extends StatefulWidget {
  

  @override
  State<Signup> createState() => _SignupState();
 Map<String, TextEditingController> _controllers_list = {
  "first_name": TextEditingController(),
  "last_name": TextEditingController(),
  "email_address_signup": TextEditingController(),
  "password_signup": TextEditingController(),
  "mobile_number":TextEditingController(),
  "ref_code": TextEditingController(),
};
}

List<String> txtlist = [  "First Name",  "Last Name",  "Email Address",  "Password",  "Mobile Number",  "Referral Code (Optional)"];

class _SignupState extends State<Signup> {
  
  @override
  // void dispose() {
  //   widget._controllers_list.values.forEach((controller) {
  //     controller.dispose();
  //   });
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          reverse: true,
          child: Container(
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 1,
                  height: MediaQuery.of(context).size.height * 0.3,
                  child: Image.asset(
                    "assets/driver_module/signup_pic.png",
                    fit: BoxFit.fitWidth,
                  ),
                ),
                Center(
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.66,
                    width: MediaQuery.of(context).size.width * 0.8,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text(
                          "SignUp",
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Expanded(
                          child: ListView.builder(
                              itemCount: txtlist.length,
                              itemBuilder: (context, index) {
                                String controllerName =
                                    widget._controllers_list.keys.elementAt(index);
                                return InputFeild(
                                  txtlist[index],
                                  null, widget._controllers_list[controllerName]!
                                );
                              }),
                        ),
                        Center(
                          child: ButtonWidget("Register Now", context, () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const NumberVerification()),
                            );
                          }),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Already have account?",
                              style: Theme.of(context).textTheme.labelLarge,
                            ),
                            TextNavigation(
                              "SignIn",
                              Theme.of(context).primaryColor,
                              context,
                              () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const Login()),
                                );
                              },
                            )
                            // text_button(
                            //     "SignIn", Theme.of(context).primaryColor, null)
                          ],
                        ),
                        // inst.but("Already have account?", "SignIn", context)
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
