import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:stranded/widgets/back_button.dart';
import 'package:stranded/widgets/button_widget.dart';

class DriverProfile extends StatefulWidget {
  @override
  State<DriverProfile> createState() => _DriverProfileState();
  Map<String, TextEditingController> _controllers_list = {
    "first_name": TextEditingController(),
    "last_name": TextEditingController(),
    "date": TextEditingController(),
    "gender": TextEditingController(),
    "email_address": TextEditingController(),
    "contact_number": TextEditingController(),
    "city": TextEditingController(),
  };
}

List<String> hint_text = [
  "First Name",
  "Last Name",
  "mm/dd/yyyy",
  "Gender",
  "Email Address",
  "Contact Number",
  "City"
];
List<IconData> icon_data = [
  Icons.person,
  Icons.person,
  Icons.calendar_month_outlined,
  Icons.male,
  CupertinoIcons.envelope,
  Icons.phone,
  Icons.location_city_sharp
];

class _DriverProfileState extends State<DriverProfile> {
  // void dispose() {
  //   widget._controllers_list.values.forEach((controller) {
  //     controller.dispose();
  //   });
  //   super.dispose();
  // }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            reverse: true,
            child: Container(
              height: MediaQuery.of(context).size.height * 1,
              width: MediaQuery.of(context).size.width * 1,
              child: Padding(
                padding: const EdgeInsets.only(top: 35),
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.all(25),
                    child: Image.asset("assets/driver_module/driver_pic.png"),
                  ),
                  Expanded(
                    child: Center(
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.9,
                        child: ListView.builder(
                            itemCount: hint_text.length,
                            itemBuilder: (context, index) {
                              return TextField(
                                controller: widget._controllers_list.values
                                    .elementAt(index),
                                decoration: InputDecoration(
                                  hintText: hint_text[index],
                                  prefixIcon: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 8, bottom: 8, right: 12),
                                    child: Container(
                                        height: 15,
                                        width: 15,
                                        decoration: BoxDecoration(
                                          color: Theme.of(context).primaryColor,
                                          border: Border.all(
                                              color: Theme.of(context)
                                                  .primaryColor),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10)),
                                        ),
                                        child: Icon(
                                          icon_data[index],
                                          color: Theme.of(context).cardColor,
                                        )),
                                  ),
                                ),
                              );
                            }),
                      ),
                    ),
                  ),
                  Padding(
                      padding: EdgeInsets.only(bottom: 50),
                      child: ButtonWidget("Save", context, () {})),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
  // CircleAvatar(
                    //   radius: 115,
                    //   child: CircleAvatar(
                    //     radius: 110,
                    //     child: CircleAvatar(
                    //       backgroundImage: widget.credentials["image"],
                    //       radius: 100,
                    //     ),
                    //   ),
                    // ),