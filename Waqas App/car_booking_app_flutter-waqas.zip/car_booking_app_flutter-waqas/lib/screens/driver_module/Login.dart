import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:stranded/screens/driver_module/Signup.dart';
import 'package:stranded/screens/driver_module/forgot_password.dart';
import 'package:stranded/screens/driver_module/number_verification.dart';
import 'package:stranded/screens/driver_module/verification.dart';
import 'package:stranded/widgets/text_navigation.dart';
import '../../widgets/button_widget.dart';

import '../../widgets/input_feild.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

TextEditingController _email_controller = TextEditingController();
TextEditingController _password_controller = TextEditingController();

class _LoginState extends State<Login> {
  // void initState() {
  //   super.initState();
  //  _email_controller = TextEditingController();
  //  _password_controller = TextEditingController();
  // }

  @override
  // void dispose() {
  //   _email_controller.dispose();
  //   _password_controller.dispose();
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: SingleChildScrollView(
          reverse: true,
          child: Container(
            child: Column(
              children: [
                Container(
                  child: Stack(
                    children: [
                      Image.asset("assets/driver_module/login_bg_pic.png"),
                      Positioned(
                          left: 80,
                          top: 150,
                          child: Image.asset(
                              "assets/driver_module/login_logo.png"))
                    ],
                  ),
                ),
                Center(
                    child: Container(
                  height: MediaQuery.of(context).size.height * 0.5,
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "Login",
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                        InputFeild("Email", Icon(Icons.alternate_email_sharp),
                            _email_controller),
                        InputFeild(
                            "Password", Icon(Icons.lock), _password_controller),
                        Padding(
                            padding: EdgeInsets.only(left: 12),
                            child: TextNavigation(
                              "Forget Password?",
                              Theme.of(context).cardColor,
                              context,
                              () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const ForgotPassword()),
                                );
                              },
                            )),
                        Center(
                            child: ButtonWidget("SignIn", context, () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const Verification()),
                          );
                          // _email_controller.clear();
                          // _password_controller.clear();
                        })),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Don't have account?",
                              style: Theme.of(context).textTheme.labelLarge,
                            ),
                            TextNavigation(
                              "Register Now!",
                              Theme.of(context).primaryColor,
                              context,
                              () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => Signup()),
                                );
                              },
                            )
                          ],
                        ),
                      ]),
                ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
