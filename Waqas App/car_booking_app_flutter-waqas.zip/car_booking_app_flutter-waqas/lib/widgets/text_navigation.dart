import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

TextNavigation(title, color, context, onPressed) {
  return TextButton(
    onPressed: onPressed,
    child: Text(
      title!,
      style: TextStyle(color: color, fontWeight: FontWeight.w700),
    ),
  );
}
