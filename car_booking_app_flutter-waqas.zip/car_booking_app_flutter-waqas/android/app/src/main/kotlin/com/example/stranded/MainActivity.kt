package com.example.stranded

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
